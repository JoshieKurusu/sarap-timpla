import React, { useState, useEffect } from "react";
import { Link , useLocation, useNavigate } from "react-router-dom";

const Header = () => {
    const [ isMenuOpen, setIsMenuOpen ] = useState(false);
    const [ isDarkMode, setIsDarkMode ] = useState(localStorage.getItem("theme") === "dark");
    const [ query, setQuery ] = useState("");
    const navigate = useNavigate();
    const location = useLocation();

    const toggleMenu = () => {
        setIsMenuOpen(!isMenuOpen);
    };

    const navigation = [
        { name: "Home", path: "/", current: location.pathname === "/" },
        { name: "Recipe", path: "/recipes", current: location.pathname.startsWith("/recipes") || location.pathname.startsWith("/search")},
        { name: "About", path: "/about", current: location.pathname === "/about"},
    ];

    function classNames(...classes) {
        return classes.filter(Boolean).join(" ");
    };

    const handleNavLinks = (event, path) => {
        event.preventDefault();
        navigate(path);
    };

    const handleSearch =  () => {
        if (query.trim() !== "") {
            navigate(`/search?query=${ encodeURIComponent(query) }`)
        }
    };

    const handleKeyPress = (event) => {
        if (event.key === "Enter") {
            handleSearch();
        }
    }

    useEffect(() => {
        document.documentElement.classList.toggle("dark", isDarkMode);
        localStorage.setItem("theme", isDarkMode ? "dark" : "light");

        if (!location.pathname.includes("/search")) {
            setQuery("");
        }
    }, [ isDarkMode, location ]);

    return (
        <header className="fixed top-0 z-50 bg-deep-maroon font-raleway md:border-b md:border-gold-accents start-0 end-0 md:static dark:bg-rich-dark-brown dark:border-soft-warm-beige">
            {/* NAVBAR */}
            <nav className="px-4 max-w-(--breakpoint-2xl) mx-auto flex-col items-center justify-center w-auto h-auto py-2.5 flex md:px-8 md:flex-row md:justify-between md:items-center">
                {/* NAVBAR CONTENT */}
                <div id="navbar-content" className={ `${isMenuOpen ? "max-h-66 opacity-100 p-4 mt-4" : "max-h-0 opacity-0 p-0 mt-0"} flex flex-col items-center justify-center transition-all duration-300 ease-in-out order-2 w-full h-auto overflow-hidden border-1 rounded-2xl border-subtle-dark-brown md:order-1 md:border-none md:p-0 md:mt-0 md:w-full md:opacity-100 md:max-h-none md:flex-row md:justify-start` }>
                    {/* BRAND LOGO */}
                    <a href="/"><img className="w-24 h-24 mb-3 md:mb-0 md:w-20 md:h-20" src="./assets/images/sarap-timpla-removebg.webp" alt="Sarap Timpla logo featuring a steaming bowl of food with a fork and wooden spoon crossed above it, surrounded by fresh vegetables like tomatoes and bell peppers." /></a>
                    {/* NAVBAR LINKS */}
                    <ul className="w-full md:w-auto md:gap-6 md:mx-auto md:flex md:flex-row md:justify-between md:items-center 2xl:text-lg">
                        { navigation.map((item) => (
                            <li key={ item.name }>
                                <Link onClick={ (event) => handleNavLinks(event, item.path) } to={ item.path } className={ `${classNames(item.current ? "bg-stone-900 text-sunny-yellow rounded-sm md:bg-transparent md:dark:bg-transparent dark:bg-elegant-warm-black dark:text-white " : "text-white dark:text-deep-orange")} font-bold w-full block px-3 py-2 transition-colors duration-300 md:w-auto md:px-1.5 md:py-1 hover:text-sunny-yellow dark:hover:text-muted-gold` }>{ item.name }</Link>
                            </li>
                        ))}
                    </ul>
                </div>
                <div className="flex flex-row items-center justify-between order-1 w-full md:order-2 md:w-auto md:flex md:flex-row md:justify-between md:items-center">
                    {/* HAMBURGER BUTTON */}
                    <button onClick={ toggleMenu } type="button" className="transition-colors duration-300 bg-transparent rounded-lg outline-none cursor-pointer w-9 h-9 hover:bg-vibrant-orange md:hidden dark:hover:bg-muted-gold" data-hs-collapse="#navbar-content" aria-controls="navbar-content" aria-label="Toggle Navigation">
                        <span className="sr-only">Open main menu</span>
                        { isMenuOpen ?
                            (
                                <svg aria-hidden="true" className="w-6 h-6 mx-auto" fill="none" id="close-menu-icon" stroke="currentColor" strokeWidth="1.5" viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg">
                                    <path className="text-white fill-current" d="M6 18 18 6M6 6l12 12" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                                </svg>
                            )
                            :
                            (
                                <svg aria-hidden="true" className="w-6 h-6 mx-auto" fill="none" id="open-menu-icon" strokeWidth="1.5" viewBox="0 0 24 24" xmlns="http://ww.w3.org/2000/svg">
                                    <path className="text-white fill-current" d="M3 5H11" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                                    <path className="text-white fill-current" d="M3 12H16" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                                    <path className="text-white fill-current" d="M3 19H21" stroke="currentColor" strokeLinecap="round" strokeLinejoin="round" strokeWidth="1.5" />
                                </svg>
                            )
                        }
                    </button>
                    <div className="flex flex-row items-center justify-between gap-2">
                        {/* SEARCH FORM */}
                        <div className="w-40 text-sm border rounded-lg outline-none border-sunny-yellow h-9 bg-deep-charcoal-gray text-stone-300 xs:w-52 hover:border-vibrant-orange dark:text-white dark:border-soft-warm-beige dark:hover:border-muted-gold">
                            <div className="flex flex-row items-center justify-between" id="navbar-searh">
                                <svg className="w-5 h-5 mx-2 text-white" xmlns="https://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <circle cx="11" cy="11" r="8" />
                                    <path d="m21 21-4.3-4.3" />
                                </svg>
                                <span className="sr-only">Search Icon</span>
                                <input type="search" id="search-form" className="w-full pr-2 text-white outline-none h-9 placeholder:text-white" placeholder="Search recipes..." value={ query } onChange={ (e) => setQuery(e.target.value) } onKeyDown={ handleKeyPress } autoComplete="off"/>
                            </div>
                        </div>
                        {/* LIGHT/DARK MODE BUTTON */}
                        <button onClick={ () => setIsDarkMode(!isDarkMode) } type="button" className="transition-colors duration-300 bg-transparent rounded-lg outline-none cursor-pointer w-9 h-9 hover:bg-vibrant-orange dark:hover:bg-muted-gold" aria-label="Light Mode Toggler" data-hs-them-click-value="light">
                            { isDarkMode ?
                                (
                                    <svg aria-hidden="true" width="1em" height="1em" className="w-6 h-6 mx-auto" data-icon="sun">
                                        <symbol id="ai:local:sun" viewBox="0 0 15 15">
                                            <path className="text-white fill-current" d="M7.5 0a.5.5 0 0 1 .5.5v2a.5.5 0 0 1-1 0v-2a.5.5 0 0 1 .5-.5M2.197 2.197a.5.5 0 0 1 .707 0L4.318 3.61a.5.5 0 0 1-.707.707L2.197 2.904a.5.5 0 0 1 0-.707M.5 7a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zm1.697 5.803a.5.5 0 0 1 0-.707l1.414-1.414a.5.5 0 1 1 .707.707l-1.414 1.414a.5.5 0 0 1-.707 0M12.5 7a.5.5 0 0 0 0 1h2a.5.5 0 0 0 0-1zm-1.818-2.682a.5.5 0 0 1 0-.707l1.414-1.414a.5.5 0 1 1 .707.707L11.39 4.318a.5.5 0 0 1-.707 0M8 12.5a.5.5 0 0 0-1 0v2a.5.5 0 0 0 1 0zm2.682-1.818a.5.5 0 0 1 .707 0l1.414 1.414a.5.5 0 1 1-.707.707l-1.414-1.414a.5.5 0 0 1 0-.707M5.5 7.5a2 2 0 1 1 4 0 2 2 0 0 1-4 0m2-3a3 3 0 1 0 0 6 3 3 0 0 0 0-6" />
                                        </symbol>
                                        <use href="#ai:local:sun"></use>
                                    </svg>
                                )
                                :
                                (
                                    <svg aria-hidden="true" width="1em" height="1em" className="w-6 h-6 mx-auto" data-icon="moon">
                                        <symbol id="ai:local:moon" viewBox="0 0 15 15">
                                            <path className="text-white fill-current" d="M2.9.5a.4.4 0 0 0-.8 0v.6h-.6a.4.4 0 1 0 0 .8h.6v.6a.4.4 0 1 0 .8 0v-.6h.6a.4.4 0 0 0 0-.8h-.6zm3 3a.4.4 0 1 0-.8 0v.6h-.6a.4.4 0 1 0 0 .8h.6v.6a.4.4 0 1 0 .8 0v-.6h.6a.4.4 0 0 0 0-.8h-.6zm-4 3a.4.4 0 1 0-.8 0v.6H.5a.4.4 0 1 0 0 .8h.6v.6a.4.4 0 0 0 .8 0v-.6h.6a.4.4 0 0 0 0-.8h-.6zM8.544.982l-.298-.04c-.213-.024-.34.224-.217.4q.211.305.389.632A6.602 6.602 0 0 1 2.96 11.69c-.215.012-.334.264-.184.417q.103.105.21.206l.072.066.26.226.188.148.121.09.187.131.176.115q.18.115.37.217l.264.135.26.12.303.122.244.086a6.6 6.6 0 0 0 1.103.26l.317.04.267.02q.19.011.384.011a6.6 6.6 0 0 0 6.56-7.339l-.038-.277a6.6 6.6 0 0 0-.384-1.415l-.113-.268-.077-.166-.074-.148a6.6 6.6 0 0 0-.546-.883l-.153-.2-.199-.24-.163-.18-.12-.124-.16-.158-.223-.2-.32-.26-.245-.177-.292-.19-.321-.186-.328-.165-.113-.052-.24-.101-.276-.104-.252-.082-.325-.09-.265-.06zm1.86 4.318a7.6 7.6 0 0 0-.572-2.894 5.601 5.601 0 1 1-4.748 10.146 7.6 7.6 0 0 0 3.66-2.51.749.749 0 0 0 1.355-.442.75.75 0 0 0-.584-.732q.093-.174.178-.355A1.25 1.25 0 1 0 10.35 6.2q.052-.442.052-.9" />
                                        </symbol>
                                        <use href="#ai:local:moon"></use>
                                    </svg>
                                )
                            }
                        </button>
                    </div>
                </div>
            </nav>
        </header>
    )
};

export default Header;