import React from "react";

const Footer = () => {
    return (
        <footer className="py-6 bg-deep-maroon dark:bg-rich-dark-brown">
            {/* FOOTER */}
            <div className="flex flex-col items-center justify-center max-w-(--breakpoint-2xl) mx-auto">
                {/* FOOTER CONTENT */}
                <img className="w-20 h-20" src="./assets/images/sarap-timpla-removebg.webp" alt="Sarap Timpla logo featuring a steaming bowl of food with a fork and wooden spoon crossed above it, surrounded by fresh vegetables like tomatoes and bell peppers." />
                {/* COPYRIGHT */}
                <p className="mt-4 text-xs text-white font-raleway text-pretty lg:text-sm 2xl:text-base dark:text-light-gray">&copy; 2025 Sarap Timpla. All Rights Reserved.</p>
            </div>
        </footer>
    )
};

export default Footer;