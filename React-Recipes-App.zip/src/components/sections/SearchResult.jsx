import React from "react";
import RecipeCard from "../ui/RecipeCard";

const SearchResult = ({ query, paddingTop = "pt-20", paddingBottom = "pb-12" }) => {
    return (
        <section>
            <div className={`${paddingTop} ${paddingBottom} max-w-(--breakpoint-2xl) mx-auto px-4 md:px-8 lg:pt-24`}>
                {/* RECIPES */}
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    {
                        query.slice(0,9).map((recipe) => (
                            <RecipeCard key={ recipe.id } recipe={ recipe } />
                        ))
                    }
                </div>
            </div>
        </section>
    )
};

export default SearchResult;