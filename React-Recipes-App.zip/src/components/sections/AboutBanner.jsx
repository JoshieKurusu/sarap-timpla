import React from "react";
import Card from "../ui/Card";

const AboutBanner = () => {
    return (
        <section>
            <div className="w-full text-white px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8 pb-11 md:pt-7 md:pb-12">
                <Card>
                    {/* TITLE */}
                    <h1 className="mb-4 text-3xl font-bold tracking-tight text-balance font-montserrat text-vibrant-orange sm:text-4xl md:mb-6 md:text-5xl 2xl:text-6xl dark:text-white">A Celebration of Filipino Flavors</h1>
                    {/* PARAGRAPH */}
                    <p className="leading-snug font-open-sans text-pretty md:text-lg dark:text-light-gray">Sarap Timpla curates authentic Filipino recipes, celebrating tradition and flavor in every dish.</p>
                </Card>
            </div>
        </section>
    )
};

export default AboutBanner;