import React from "react";
import { useParams } from "react-router-dom";
import recipesData from "/src/assets/data/recipes.json";
import ImageCard from "../ui/ImageCard";
import RecipeTitle from "../ui/RecipeTitle";

const RecipeSection = () => {
    const { dishName } = useParams();
    const selectedRecipe = recipesData.find(recipe => recipe.slug === dishName);

    return (
        <section>
            {/* RECIPE IMAGE BANNER */}
            <div className="px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8">
                { selectedRecipe ? <ImageCard recipe={ selectedRecipe } /> : <em className="font-semibold font-raleway dark:text-very-light-gray">No Recipe Image Found.</em> }
            </div>
            {/* RECIPE TITLE */}
            <div className="mt-10 mb-4 text-3xl font-bold text-center recipe-title sm:text-4xl md:text-6xl 2xl:text-7xl">
                { selectedRecipe ? <RecipeTitle recipe={ selectedRecipe } /> : <em className="font-semibold font-raleway dark:text-very-light-gray">No Recipe Title Found.</em> }
            </div>
        </section>
    )
};

export default RecipeSection;