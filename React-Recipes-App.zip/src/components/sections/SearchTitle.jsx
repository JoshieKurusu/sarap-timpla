import React from "react";
import Card from "../ui/Card";

const SearchTitle = ({ query }) => {
    return (
        <section>
            <div className="w-full px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8">
                <Card>
                    {/* TITLE */}
                    <h1 className="text-3xl font-bold tracking-tight text-center text-vibrant-orange font-montserrat md:text-4xl lg:text-5xl xl:text-6xl dark:text-white">Result for: { query }</h1>
                </Card>
            </div>
        </section>
    )
};

export default SearchTitle;