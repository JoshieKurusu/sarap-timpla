import React from "react";
import Card from "../ui/Card";

const Discover = () => {
    return (
        <section>
            <div className="w-full pt-10 px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8 md:pt-16 lg:pt-26">
                <Card>
                    {/* SUBTITLE */}
                    <p className="text-sm font-medium font-raleway text-sunny-yellow lg:text-base dark:text-very-light-gray">Discover, Savor, Celebrate — Together</p>
                    {/* TITLE */}
                    <h1 className="my-5 text-4xl font-bold text-vibrant-orange font-montserrat text-balance md:text-5xl dark:text-white">Embrace the Flavors of the Philippines</h1>
                    {/* PARAGRAPH */}
                    <p className="text-lg text-white font-open-sans 2xl:text-xl dark:text-light-gray">Sarap Timpla is your gateway to the soul of Filipino cooking, where tradition meets passion. Explore curated recipes that honor our culinary heritage—from time-honored favorites to modern twists inspired by Filipino ingenuity. Every dish tells a story. Every bite feels like home.</p>
                </Card>
            </div>
        </section >
    )
};

export default Discover;