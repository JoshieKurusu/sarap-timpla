import React from "react";
import { useNavigate } from "react-router-dom";

const ExploreSection = () => {
    const navigate = useNavigate();

    const recipesBtn = () => {
        navigate("/recipes");
        setTimeout(() => window.location.reload(), 100);
    }

    return (
        <>
            {/* EXPLORE MORE BUTTON */}
            <div className="flex flex-row items-center justify-center w-full pb-10 md:pb-20">
                <button onClick={ recipesBtn } type="button" className="flex flex-row items-center justify-center px-4 py-3 font-medium text-black transition duration-300 outline-none cursor-pointer w-3xs group bg-sunny-yellow rounded-xl font-nunito hover:bg-vibrant-orange dark:bg-deep-orange dark:text-white dark:hover:bg-muted-gold" aria-label="Navigate to Recipes page">Explore more
                    <svg className="w-5 h-5 transition ease-in-out group-hover:translate-x-1" fill="currentColor" viewBox="0 0 20 20" xmlns="http://www.w3.org/2000/svg">
                        <path clipRule="evenodd" fillRule="evenodd" d="M8.22 5.22a.75.75 0 0 1 1.06 0l4.25 4.25a.75.75 0 0 1 0 1.06l-4.25 4.25a.75.75 0 0 1-1.06-1.06L11.94 10 8.22 6.28a.75.75 0 0 1 0-1.06Z" />
                    </svg>
                </button>
            </div>
        </>
    )
};

export default ExploreSection;