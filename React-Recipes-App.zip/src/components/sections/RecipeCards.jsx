import React, { useEffect, useState } from "react";
import recipesData from "/src/assets/data/recipes.json";
import RecipeCard from "../ui/RecipeCard";

const itemsPerPage = 9;

const RecipeCards = ({ isHome = false, paddingTop = "pt-20", paddingBottom = "pb-12" }) => {
    const [ cards, setCards ] = useState([]);
    const [ currentPage, setCurrentPage ] = useState(1);

    useEffect(() => {
        if(recipesData.length > 0) {
            setCards(isHome ? recipesData.slice(0, 6) : recipesData); // Use `isHome` logic inside state
        }
    }, [ recipesData, isHome ]);

    const totalPages = Math.ceil(cards.length / itemsPerPage);
    const startIndex = (currentPage - 1) * itemsPerPage;
    const endIndex = startIndex + itemsPerPage;
    const currentCards = cards.slice(startIndex, endIndex);

    const handlePageClick = (page) => setCurrentPage(page);

    const getPageNumbers = () => {
        const pages = [];
        if(totalPages <= 10) {
            for(let i = 1; i <= totalPages; i++) pages.push(i);
        } else {
            pages.push(1);
            if(currentPage > 4) pages.push("...");
            for(let i = Math.max(2, currentPage - 2); i <= Math.min(totalPages - 1, currentPage + 2); i++) {
                pages.push(i);
            }
            if(currentPage < totalPages - 3) pages.push("...");
            pages.push(totalPages);
        }
        return pages;
    };
    return (
        <section id="recipeSection">
            {/* RECIPES CARD */}
            <div className={`${paddingTop} ${paddingBottom} max-w-(--breakpoint-2xl) mx-auto px-4 md:px-8 lg:pt-24`}>
                {/* RECIPES */}
                <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
                    { currentCards.map((recipe) => (
                        <RecipeCard key={ recipe.id } recipe={ recipe } />
                    )) }
                </div>
            </div>
            {/* RECIPES PAGINATION */}
            <div className={`${ isHome ? "hidden" : "block" } w-full max-w-(--breakpoint-2xl) mx-auto flex flex-row items-center justify-center gap-2 pt-10 pb-23 px-4 md:px-8 lg:justify-end`}>
                <button className="w-auto bg-transparent rounded-lg transition-colors duration-300 font-nunito text-black outline-none group inline-flex items-center justify-center px-2.5 py-2 text-sm gap-x-1.5 font-bold cursor-pointer hover:bg-vibrant-orange dark:text-white dark:hover:bg-muted-gold" onClick={ () => setCurrentPage((prev) => Math.max(prev - 1, 1)) } disabled={ currentPage === 1 }>
                    <svg className="w-3.5 h-3.5 shrink-0 transition ease-in-out group-hover:-translate-x-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m15 18-6-6 6-6" />
                    </svg>
                    <span className="hidden sm:inline-block">Previous</span>
                </button>
                { getPageNumbers().map((page, index) => (
                    <button className={`${ currentPage  === page ? "bg-vibrant-orange dark:bg-deep-orange" : "bg-transparent" } w-9 h-9 rounded-lg transition-colors duration-300 cursor-pointer hover:bg-vibrant-orange dark:text-white dark:hover:bg-muted-gold`} key={ index } onClick={ () => typeof page === "number" && handlePageClick(page) } disabled={ page === "..." }>{ page }</button>
                )) }
                <button className="w-auto bg-transparent rounded-lg transition-colors duration-300 font-nunito text-black outline-none group inline-flex items-center justify-center px-2.5 py-2 text-sm gap-x-1.5 font-bold cursor-pointer hover:bg-vibrant-orange dark:text-white dark:hover:bg-muted-gold" onClick={ () => setCurrentPage((prev) => Math.min(prev + 1, totalPages)) } disabled={ currentPage === totalPages }>
                    <span className="hidden sm:inline-block">Next</span>
                    <svg className="w-3.5 h-3.5 shrink-0 transition ease-in-out group-hover:translate-x-1" xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                        <path d="m9 18 6-6-6-6" />
                    </svg>
                </button>
            </div>
        </section>
    );
};

export default RecipeCards;
