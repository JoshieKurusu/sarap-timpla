import React from "react";

const GreetingSection = () => {
    return (
        <section>
            <div className="w-full py-6 px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8 md:py-12">
                <div className="flex flex-col items-center justify-between gap-5 md:gap-6 md:flex-row">
                    {/* TEXT */}
                    <div className="space-y-2 md:w-1/2 md:space-y-4 xl:max-w-xl">
                        {/* TITLE */}
                        <h3 className="text-3xl font-bold tracking-tight text-balance font-montserrat lg:text-4xl 2xl:text-5xl dark:text-white">The Heart of Filipino Cooking</h3>
                        {/* PARAGRAPH */}
                        <p className="text-pretty font-open-sans sm:text-lg 2xl:text-xl dark:text-light-gray">Filipino cuisine is more than just food — it's a reflection of home, comfort, and the flavors that bring people together. At Sarap Timpla, we curate a collection of thoughtfully selected recipes that embody the warmth of Filipino cooking, making it easy to recreate beloved dishes in your own kitchen. Whether it's a simple everyday meal or a festive feast, every dish carries the essence of tradition and love.</p>
                    </div>
                    {/* ILLUSTRATION */}
                    <div className="md:w-1/2 xl:w-full xl:max-w-xl">
                        <img className="w-full h-auto mx-auto rounded-xl min-w-60 min-h-44 max-w-117 max-h-88" src="./assets/images/people-cooking-illustration-removebg.webp" alt="Two people cooking together, one stirring a pot and the other chopping vegetables." />
                    </div>
                </div>
            </div>
        </section>
    )
};

export default GreetingSection;