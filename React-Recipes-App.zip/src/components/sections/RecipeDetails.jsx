import React from "react";
import { useParams } from "react-router-dom";
import recipesData from "/src/assets/data/recipes.json";
import Instruction from "../ui/Instruction";
import Ingredients from "../ui/Ingredients";
import Notes from "../ui/Notes";
import Tags from "../ui/Tags";

const RecipeDetails = () => {
    const { dishName } = useParams();
    const selectedRecipe = recipesData.find(recipe => recipe.slug === dishName);

    return (
        <section>
            <div className="max-w-(--breakpoint-2xl) mx-auto flex flex-col items-start justify-center h-full gap-12 mt-10 mb-6 px-4 md:px-8 md:mb-0 md:mt-18 md:flex-row">
                <div className="w-full max-w-2xl mx-auto md:mx-0">
                    {/* RECIPE INSTRUCTIONS */}
                    <div className="pb-6 sm:pb-8 lg:pb-12">
                        { selectedRecipe ? <Instruction recipe={ selectedRecipe } /> : <em className="font-semibold font-raleway dark:text-very-light-gray">Instructions not found.</em> }
                    </div>
                    {/* RECIPE NOTES */}
                    <div className="py-6 sm:py-8 lg:py-12">
                        { selectedRecipe ? <Notes recipe={ selectedRecipe } /> : <em className="font-semibold font-raleway dark:text-very-light-gray">Notes not found.</em> }
                    </div>
                </div>
                {/* RECIPE INGREDIENTS */}
                <div className="w-full max-w-2xl mx-auto md:max-w-78 md:mx-0">
                    { selectedRecipe ? <Ingredients recipe={ selectedRecipe } /> : <em className="font-semibold font-raleway dark:text-very-light-gray">Ingredients not found.</em> }
                </div>
            </div>
            <div className="flex flex-row items-center justify-center pb-16 max-w-(--breakpoint-2xl) mx-auto px-4 md:px-8 md:pb-9">
                <div className="w-full max-w-5xl">
                    <Tags tags={ selectedRecipe?.tags || [] } />
                </div>
            </div>
        </section>
    )
};

export default RecipeDetails;