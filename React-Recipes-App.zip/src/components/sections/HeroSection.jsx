import React from "react";

const Hero = () => {
    const exploreBtn = () => {
        const recipeSection = document.querySelector("#recipeSection");
        if(recipeSection) {
            recipeSection.scrollIntoView({ behavior: "smooth" });
            console.log("Smooth scrolling to recipe section");
        } else {
            console.warn("The recipe section was not found.");
        }
    }
    return (
        <section>
            <div className="flex flex-col items-center justify-center w-full gap-6 px-4 max-w-(--breakpoint-2xl) mx-auto sm:gap-10 md:px-8 md:gap-3 md:pt-12 md:flex-row md:justify-between md:items-center lg:pt-13">
                {/* TEXT AND EXPLORE BUTTON */}
                <div className="w-auto md:w-full">
                    {/* TEXT */}
                    <div className="mt-12 mb-8 sm:text-center md:mb-12 md:text-left md:mt-0">
                        {/* TITLE */}
                        <h1 className="mb-3 text-4xl font-bold font-montserrat w-72 xs:w-auto sm:w-xl sm:mx-auto md:w-sm md:mb-6 md:mx-0 md:text-5xl lg:text-6xl lg:w-md xl:w-xl dark:text-white">Sarap Timpla — A Flavorful Journey into Filipino Cuisine</h1>
                        {/* PARAGRAPH */}
                        <p className="text-base font-open-sans text-neutral-dark-gray sm:w-2xl sm:mx-auto md:w-88 md:mx-0 md:text-lg lg:w-md xl:w-lg 2xl:text-xl dark:text-light-gray">
                            Welcome to Sarap Timpla, your ultimate destination for delicious recipes and kitchen inspiration! Discover mouthwatering Filipino dishes, explore flavors that bring families together. Let's celebrate the joy of cooking!
                        </p>
                    </div>
                    {/* EXPLORE BUTTON */}
                    <div className="w-full sm:w-96 sm:mx-auto md:mx-0 md:w-69 2xl:w-76">
                        <button onClick={ exploreBtn } type="button" className="w-full px-8 py-3 text-sm font-bold text-black transition duration-300 outline-none cursor-pointer bg-sunny-yellow rounded-xl font-nunito hover:bg-vibrant-orange hover:shadow-lg md:text-base 2xl:text-lg dark:bg-deep-orange dark:text-white dark:hover:bg-muted-gold">Explore Recipes</button>
                    </div>
                </div>
                {/* IMAGE/ILLUSTRATION */}
                <div className="w-full">
                    <img className="w-full h-auto mx-auto max-h-99" src="./assets/images/family-preparing-illustration-removebg.webp" alt="Mother and daughter making traditional rice dumplings in a kitchen."/>
                </div>
            </div>
        </section>
    )
};

export default Hero;