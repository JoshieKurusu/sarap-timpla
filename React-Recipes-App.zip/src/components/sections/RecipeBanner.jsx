import React from "react";
import Card from "../ui/Card";

const BannerSection = () => {
    return (
        <section>
            <div className="w-full px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8">
                <Card maxWidth="lg:max-w-4xl">
                    <div className="flex flex-row items-center justify-center xl:gap-6">
                        {/* TITLE */}
                        <div className="w-auto max-w-md sm:max-w-lg md:max-w-xs lg:max-w-sm xl:max-w-115">
                            <h1 className="text-2xl font-bold tracking-tight text-center text-vibrant-orange font-montserrat md:text-left md:text-3xl lg:text-4xl xl:text-5xl dark:text-white">Taste the tradition. Cook with passion. Celebrate Filipino flavors.</h1>
                        </div>
                        {/* ILLUSTRATION */}
                        <div className="hidden w-auto h-auto md:block md:max-w-54 md:max-h-56 lg:max-w-77 lg:max-h-85">
                            <img className="md:ml-auto md:w-54 md:h-56 lg:w-full lg:h-70 lg:ml-0" src="./assets/images/dish-illustration.webp" alt="Nasi Lemak with rice, fried chicken, sambal, and traditional sides on a banana leaf." />
                        </div>
                    </div>
                </Card>
            </div>
        </section>
    )
};

export default BannerSection;