import React from "react";

const InvitationSection = () => {
    return (
        <section>
            <div className="w-full py-6 px-4 max-w-(--breakpoint-2xl) mx-auto md:px-8 md:py-12">
                <div className="flex flex-col items-center justify-between gap-5 md:gap-6 md:flex-row">
                    {/* ILLUSTRATION */}
                    <div className="md:w-1/2 xl:w-full xl:max-w-xl">
                        <img className="w-full h-auto mx-auto rounded-xl min-w-60 min-h-44 max-w-117 max-h-88" src="./assets/images/eating-together-illustration-removebg.webp" alt="Three people sharing a meal at a table covered with a blue tablecloth." />
                    </div>
                    {/* TEXT */}
                    <div className="space-y-2 md:w-1/2 md:space-y-4 xl:max-w-xl">
                        {/* TITLE */}
                        <h3 className="text-3xl font-bold tracking-tight text-balance font-montserrat lg:text-4xl 2xl:text-5xl dark:text-white">Taste the Stories, Share the Flavors</h3>
                        {/* PARAGRAPH */}
                        <p className="text-pretty font-open-sans sm:text-lg 2xl:text-xl dark:text-light-gray">Every Filipino dish carries a story — of family gatherings, festive celebrations, and cherished traditions passed down through generations. Sarap Timpla brings these flavors to life through a curated selection of recipes that honor our culinary heritage. Whether you're cooking for loved ones or simply indulging in the joy of Filipino cuisine, let every meal be a celebration of culture and connection.</p>
                    </div>
                </div>
            </div>
        </section>
    )
};

export default InvitationSection;