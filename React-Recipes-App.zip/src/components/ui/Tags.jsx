import React from "react";
import { useLocation } from "react-router-dom";

const Tags = ({ tags = [] }) => {
    const location = useLocation();
    const isRecipePage = location.pathname.startsWith("/recipes/");

    return (
        <div className="flex flex-row items-center gap-2.5 mt-auto">
            {
                tags.length > 0 ? (
                    tags.map((tag, index) => (
                        <span className={ `${ isRecipePage ? "shadow-lg" : "" } w-auto rounded-lg bg-light-beige px-3 py-1.5 text-xs font-semibold text-dark-brown font-open-sans group-hover:bg-beige group-hover:shadow-lg 2xl:text-sm dark:bg-lighter-charcoal dark:text-light-gray dark:group-hover:bg-rich-dark-brown` } key={ index }>{ tag }</span>
                    ))
                )
                :
                <em className="font-semibold font-raleway dark:text-very-light-gray">No tags available.</em>
            }
        </div>
    )
};

export default Tags;