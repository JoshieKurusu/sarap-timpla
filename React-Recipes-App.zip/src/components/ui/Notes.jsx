import React from "react";

const Notes = ({ recipe }) => {
    return (
        // RECIPE NOTES
        <div>
            {/* TITLE */}
            <h2 className="text-3xl font-bold font-raleway lg:text-4xl 2xl:text-5xl dark:text-white">Recipe Notes:</h2>
            {/* NOTES CONTENT */}
            <ul role="list" className="mt-4 text-lg leading-normal list-disc list-outside ps-5 text-pretty marker:text-vibrant-orange md:pl-5 2xl:text-xl dark:marker:text-deep-orange">
                {
                    recipe.recipeNotes.map((recipeNote, recipeNoteIndex) => (
                        <li key={ recipeNoteIndex } className="mb-2 font-open-sans last:mb-0 dark:text-light-gray">{ recipeNote }</li>
                    ))
                }
            </ul>
        </div>
    )
};

export default Notes;