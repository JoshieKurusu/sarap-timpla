import React, { useState } from "react";

const Ingredients = ({ recipe }) => {
    const [ servingSize, setServingSize ] = useState(recipe.recipeServing || 1);

    const convertFractionToDecimal = (quantity) => {
        if(typeof quantity === "string" && quantity.includes("/")) {
            const parts = quantity.split(" ");
            if(parts.length === 2) {
                const whole = parseInt(parts[0], 10);
                const [ numerator, denominator ] = parts[1].split("/").map(Number);
                return whole + (numerator / denominator);
            }
            const [ numerator, denominator ] = quantity.split("/").map(Number);
            return numerator / denominator;
        }
        return parseFloat(quantity);
    }

    const formatQuantity = (quantity) => {
        if(!quantity) return "";
        const num = parseFloat(quantity);
        return Number.isInteger(num) ? num.toString() : num.toFixed(2).replace(/\.00$/, "");
    };

    return (
        // RECIPE INGREDIENTS
        <div>
            {/* TITLE */}
            <h2 className="text-3xl font-bold font-raleway lg:text-4xl 2xl:text-5xl dark:text-white">Ingredients:</h2>
            {/* PER SERVING INPUT */}
            <div className="py-6">
                {/* LABEL */}
                <label htmlFor="serving-size" className="mb-1 text-base font-raleway dark:text-very-light-gray">Serving size</label>
                <div className="flex items-center justify-start border rounded-lg border-gold-accents w-max dark:border-soft-warm-beige">
                    {/* INPUT FORM */}
                    <input type="number" id="serving-size" name="serving-size" className="h-10 px-2 py-3 w-full max-w-18 bg-vibrant-orange font-open-sans rounded-s-lg focus:outline-none [appearance:textfield] [&::-webkit-inner-spin-button]:appearance-none [&::-webkit-outer-spin-button]:appearance-none dark:text-off-white dark:bg-muted-gold" min="1" step="1" value={ servingSize } readOnly disabled/>
                    {/* PLUS/MINUS BUTTONS */}
                    <div>
                        {/* MINUS */}
                        <button onClick={ () => setServingSize(prev => (prev > 1 ? prev - 1 : 1)) } type="button" className="inline-flex items-center justify-center w-10 h-10 text-sm font-medium text-black transition duration-300 rounded-none outline-none cursor-pointer bg-sunny-yellow font-nunito hover:bg-vibrant-orange dark:bg-deep-orange dark:text-white dark:hover:bg-muted-gold">
                            <svg className="w-3.5 h-3.5 shrink-0" xmlns="http:www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M5 12h14" />
                            </svg>
                        </button>
                        {/* PLUS */}
                        <button onClick={ () => setServingSize(prev => Number(prev) + 1) } type="button" className="inline-flex items-center justify-center w-10 h-10 text-sm font-medium text-black transition duration-300 rounded-none outline-none cursor-pointer bg-sunny-yellow font-nunito last:rounded-e-lg hover:bg-vibrant-orange dark:bg-deep-orange dark:text-white dark:hover:bg-muted-gold">
                            <svg className="w-3.5 h-3.5 shrink-0" xmlns="http:www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                <path d="M5 12h14" />
                                <path d="M12 5v14" />
                            </svg>
                        </button>
                    </div>
                </div>
            </div>
            {/* INGREDIENTS CONTENT */}
            <ul role="list" className="divide-y divide-vibrant-orange max-w-78 md:max-w-none dark:divide-soft-warm-beige">
                {
                    recipe.ingredients.map((ingredient) => (
                        ingredient.items.map((item, itemIndex) => {
                            // EXTRACT TEXT INSIDE PARENTHESES
                            const match = item.name.match(/\((.*?)\)/);
                            const mainName = item.name.replace(/\(.*?\)/, "").trim();
                            const parentheticalText = match ? match[1] : null;

                            return (
                                <li key={ itemIndex } className={ `${ item.quantity ? "gap-x-2" : "gap-x-0" } font-open-sans inline-flex w-full px-4 py-3 text-sm xl:text-base dark:text-light-gray` }>
                                    <span>{ item.quantity ? formatQuantity((convertFractionToDecimal(item.quantity) / recipe.recipeServing) * servingSize) : "" }</span>
                                    <span>{ mainName } { parentheticalText && <em className="text-xs font-normal font-raleway xl:text-sm dark:text-very-light-gray">({ parentheticalText })</em> }</span>
                                </li>
                            );
                        })
                    ))
                }
            </ul>
        </div>
    )
};

export default Ingredients;