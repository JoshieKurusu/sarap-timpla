import React from "react";

const RecipeTitle = ({ recipe }) => {
    return (
        <>
            <h1 className="max-w-3xl mx-auto font-montserrat 2xl:max-w-4xl dark:text-white">{ recipe.title }</h1>
        </>
    )
}

export default RecipeTitle