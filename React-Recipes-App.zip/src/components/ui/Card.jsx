import React from "react";

const Card = ({ children, maxWidth = "max-w-3xl" }) => {
    return (
        <div className="bg-deep-charcoal-gray rounded-xl dark:bg-charcoal-gray">
            <div className={ `${ maxWidth } py-10 px-4 mx-auto text-center md:px-8 lg:py-16 lg:px-0` }>
                { children }
            </div>
        </div>
    )
};

export default Card;