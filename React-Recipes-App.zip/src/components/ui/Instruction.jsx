import React, { useState } from "react";

const Instruction = ({ recipe }) => {
    const [ activeStep, setActiveStep ] = useState(0);
    const [ viewMode, setViewMode ] = useState("step-by-step");

    return (
        // RECIPE INSTRUCTIONS
        <div>
            {/* TITLE */}
            <h2 className="text-3xl font-bold font-raleway lg:text-4xl 2xl:text-5xl dark:text-white">Instructions:</h2>
            {/* STEP BY STEP & VIEW ALL STEPS BUTTONS */}
            <div className="inline-flex flex-row items-center justify-center w-full my-8">
                <div className="w-auto p-1 rounded-lg bg-sunny-yellow dark:bg-elegant-warm-black">
                    <button onClick={ () => setViewMode("step-by-step") } type="button" className={ `${ viewMode === "step-by-step" ? "bg-vibrant-orange dark:bg-deep-orange dark:text-off-white" : "bg-transparent" } mr-1 px-4 py-3 font-bold text-sm text-black transition duration-300 cursor-pointer rounded-xl font-nunito outline-none hover:bg-vibrant-orange 2xl:text-base dark:text-white dark:hover:bg-muted-gold` }>Step-by-Step</button>
                    <button onClick={ () => setViewMode("view-all") } type="button" className={ `${ viewMode === "view-all" ? "bg-vibrant-orange dark:bg-deep-orange dark:text-off-white" : "bg-transparent" } ml-1 px-4 py-3 font-bold text-sm text-black transition duration-300 cursor-pointer rounded-xl font-nunito outline-none hover:bg-vibrant-orange 2xl:text-base dark:text-white dark:hover:bg-muted-gold` }>View All Steps</button>
                </div>
            </div>
            {/* STEP BY STEP */}
            {
                viewMode === "step-by-step" && (
                    <div>
                        {/* STEP */}
                        <ul className="flex flex-row items-center justify-between gap-2">
                            {
                                recipe.steps.map((step, index) => (
                                    <li key={ index } className={ `${ activeStep === index ? "font-bold text-primary" : "" } flex items-center flex-1 group shrink basis-0 gap-2` }>
                                        <span className="inline-flex items-center text-xs align-middle font-raleway dark:text-very-light-gray">
                                            {/* NUMBER STEP */}
                                            <span className={ `${ index < activeStep ? "bg-vibrant-orange dark:bg-deep-orange" : activeStep === index ? "bg-vibrant-orange dark:bg-deep-orange" : "bg-sunny-yellow dark:bg-muted-gold" } flex items-center justify-center font-medium rounded-full w-7 h-7` }>{ index + 1 }</span>
                                            {/* TEXT */}
                                            <span className="hidden text-sm font-medium ms-2 sm:inline-block 2xl:text-base">Step</span>
                                        </span>
                                        <div className="flex-1 w-full h-px transition duration-300 bg-stone-600 group-last:hidden hs-stepper-success:bg-secondary hs-stepper-completed:bg-secondary-accent dark:hs-stepper-success:bg-primary dark:hs-stepper-completed:bg-primary-accent-dark dark:bg-muted-gold"></div>
                                    </li>
                                ))
                            }
                        </ul>
                        {/* STEPS CONTENT */}
                        <ul className="h-full p-4 mt-5 overflow-hidden border border-dashed rounded-xl md:mt-8 dark:border-muted-gold">
                            {
                                recipe.steps.map((step, index) => (
                                    <ul role="list" key={ index } className={ `${ activeStep === index ? "block" : "hidden" } mt-1 space-y-2 text-lg leading-normal list-disc list-outside ps-5 text-balance marker:text-vibrant-orange md:pl-5 2xl:text-xl dark:marker:text-deep-orange` }>
                                        {
                                            step.actions.map((action, actionIndex) => (
                                                <li key={ actionIndex } className="font-open-sans dark:text-light-gray">{ action }</li>
                                            ))
                                        }
                                    </ul>
                                ))
                            }
                        </ul>
                        {/* STEPS BUTTON */}
                        <div className="flex flex-row items-center justify-between mt-5">
                            <button onClick={ () => setActiveStep((prev) => Math.max(prev - 1, 0)) } type="button" className={ `${ activeStep === 0 ? "bg-neutral-dark-gray cursor-default opacity-80 dark:text-off-white dark:bg-elegant-warm-black" : "bg-sunny-yellow cursor-pointer hover:bg-vibrant-orange dark:bg-deep-orange dark:hover:bg-muted-gold" } inline-flex items-center justify-center px-2.5 py-2 text-sm gap-x-1.5 rounded-lg font-bold font-nunito text-black transition duration-300 outline-none group hover:shadow-lg dark:text-white` } disabled={activeStep === 0}>
                                <svg className={ `${ activeStep === 0 ? "group-hover:translate-none" : "group-hover:-translate-x-1" } w-3.5 h-3.5 shrink-0 transition ease-in-out` } xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="m15 18-6-6 6-6" />
                                </svg>
                                <span className="hidden sm:inline-block">Back</span>
                            </button>
                            <button onClick={ () => setActiveStep((prev) => Math.min(prev + 1, recipe.steps.length - 1)) } type="button" className={ `${ activeStep === recipe.steps.length - 1 ? "bg-neutral-dark-gray cursor-default opacity-80 dark:text-off-white dark:bg-elegant-warm-black" : "bg-sunny-yellow cursor-pointer hover:bg-vibrant-orange dark:bg-deep-orange dark:hover:bg-muted-gold" } inline-flex items-center justify-center px-2.5 py-2 text-sm gap-x-1.5 rounded-lg font-bold font-nunito text-black transition duration-300 outline-none group hover:shadow-lg dark:text-white` } disabled={activeStep === recipe.steps.length - 1}>
                                <span className="hidden sm:inline-block">Next</span>
                                <svg className={ `${ activeStep === recipe.steps.length - 1 ? "group-hover:translate-none" : "group-hover:translate-x-1" } w-3.5 h-3.5 shrink-0 transition ease-in-out` } xmlns="http://www.w3.org/2000/svg" width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
                                    <path d="m9 18 6-6-6-6" />
                                </svg>
                            </button>
                        </div>
                    </div>
                )
            }
            {/* VIEW ALL STEPS */}
            {
                viewMode === "view-all" && (
                    <div>
                        {
                            recipe.steps.map((step, index) => (
                                <div key={ index } className="mb-6">
                                    {/* STEPS */}
                                    <div className="space-x-1 text-lg font-bold font-raleway text-balance 2xl:text-xl dark:text-very-light-gray">
                                        {/* TEXT */}
                                        <span>Step</span>
                                        {/* NUMBER STEP */}
                                        <span>{ index + 1 }</span>
                                    </div>
                                    {/* STEPS CONTENT */}
                                    <ul role="list" className="mt-1 space-y-2 text-lg font-normal leading-normal list-disc list-outside ps-5 text-pretty marker:text-vibrant-orange md:pl-5 2xl:text-xl dark:marker:text-deep-orange">
                                        {
                                            step.actions.map((action, actionIndex) => (
                                                <li key={ actionIndex } className="text-balance font-open-sans dark:text-light-gray">{ action }</li>
                                            ))
                                        }
                                    </ul>
                                </div>
                            ))
                        }
                    </div>
                )
            }
        </div>
    )
};

export default Instruction;