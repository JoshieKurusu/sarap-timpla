import React from "react";

const ImageCard = ({ recipe }) => {
    return (
        <div className="w-full mx-auto overflow-hidden h-80">
            <img className="object-cover w-full h-full rounded-xl" src={ recipe.image } alt={ recipe.imageAlt } loading="lazy"/>
        </div>
    )
};

export default ImageCard;