import React from "react";
import { useNavigate } from "react-router-dom";
import Tags from "./Tags";

const RecipeCard = ({ recipe }) => {
    const navigate = useNavigate();

    const handleCardClick = (event) => {
        event.preventDefault();
        navigate(`/recipes/${ recipe.slug }`);
    };
    return (
        <div className="flex flex-col h-full p-5 align-baseline transition-all duration-300 border cursor-pointer border-subtle-dark-brown rounded-xl outline-hidden hover:border-transparent group hover:shadow-lg hover:bg-pale-yellow hover:shadow-gray-500 dark:border-soft-warm-beige dark:hover:bg-lighter-charcoal" id={ recipe.id } onClick={ handleCardClick }>
            {/* CARD HEADER */}
            <div className="overflow-clip rounded-xl">
                {/* IMAGE/ILLUSTRATION */}
                <img className="object-cover w-full transition duration-500 rounded-xl hover:scale-110 aspect-3/2" src={ recipe.image } alt={ recipe.imageAlt } />
            </div>
            {/* CARD BODY */}
            <div className="my-6">
                {/* RECIPE TITLE */}
                <h3 className="mb-5 text-2xl font-bold font-montserrat 2xl:text-3xl dark:text-white">{ recipe.title }</h3>
                {/* RECIPE PARAGRAPH */}
                <p className="text-neutral-dark-gray font-open-sans 2xl:text-xl dark:text-light-gray">{ recipe.description }</p>
            </div>
            {/* RECIPE TAGS */}
            <Tags tags={ recipe.tags } />
        </div>
    )
};

export default RecipeCard;