import { HashRouter as Router, Routes, Route } from "react-router-dom";
import Header from "./components/layout/Header";
import Footer from "./components/layout/Footer";
import Home from "./pages/Home";
import Recipes from "./pages/Recipes/Recipes";
import Recipe from "./pages/Recipes/Recipe";
import About from "./pages/About";
import NotFound from "./pages/NotFound";

function App() {
    return (
        <Router>
            <Header />
            <Routes>
                <Route path="/" element={ <Home /> } />
                <Route path="/recipes" element={ <Recipes /> } />
                <Route path="/recipes/:dishName" element={ <Recipe /> } />
                <Route path="/about" element={ <About /> } />
                <Route path="*" element={ <NotFound /> } />
            </Routes>
            <Footer />
        </Router>
    );
}

export default App;