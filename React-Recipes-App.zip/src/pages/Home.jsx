import React from "react";
import HeroSection from "../components/sections/HeroSection";
import DiscoverSection from "../components/sections/DiscoverSection";
import RecipeCards from "../components/sections/RecipeCards";
import ExploreSection from "../components/sections/ExploreSection";

const Home = () => {
    return (
        <main className="pt-16 md:pt-2.5 lg:pt-0 bg-cream dark:bg-deep-charcoal-gray">
            <HeroSection />
            <DiscoverSection />
            <RecipeCards isHome={ true }/>
            <ExploreSection />
        </main>
    )
};

export default Home;