import React from "react";
import { useNavigate } from "react-router-dom";

const NotFound = () => {
    const navigate = useNavigate();

    const recipesBtn = () => {
        navigate("/recipes");
    }

    return (
        <main className="bg-cream dark:bg-deep-charcoal-gray">
            <section className="max-w-(--breakpoint-2xl) mx-auto">
                <div className="flex flex-col items-center justify-center w-full h-screen max-w-2xl px-4 py-8 mx-auto text-center lg:px-6 lg:py-16">
                    {/* TITLE */}
                    <h1 className="font-extrabold font-montserrat text-7xl text-vibrant-orange lg:text-9xl dark:text-white">404</h1>
                    {/* SUBTITLE */}
                    <h3 className="my-4 text-3xl font-bold tracking-tight text-balance font-raleway text-sunny-yellow md:text-4xl dark:text-very-light-gray">Oh no, looks like this page took a wrong turn!</h3>
                    {/* PARAGRAPH */}
                    <p className="text-lg text-pretty font-open-sans text-neutral-dark-gray dark:text-light-gray">
                        Don't worry — delicious discoveries are just a click away. Head back to our Recipes and uncover mouthwatering dishes waiting to be explored. A feast of flavors is calling.
                    </p>
                    {/* BACK BUTTON */}
                    <button type="button" className="px-8 py-3 mt-4 text-sm font-bold text-center transition duration-300 outline-none cursor-pointer bg-sunny-yellow rounded-xl font-nunito md:text-base 2xl:text-lg hover:-translate-y-1 hover:shadow-2xl hover:shadow-primary hover:bg-vibrant-orange dark:bg-deep-orange dark:text-white dark:hover:bg-muted-gold" onClick={ recipesBtn }>Back to Recipes</button>
                </div>
            </section>
        </main>
    )
};

export default NotFound;