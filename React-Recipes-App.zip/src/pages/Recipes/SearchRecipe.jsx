import React from "react";
import { useState, useEffect } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import recipesData from "/src/assets/data/recipes.json";
import SearchTitle from "../../components/sections/SearchTitle";
import SearchResult from "../../components/sections/SearchResult";

const SearchRecipe = () => {
    const [ results, setResults ] = useState(null);
    const location = useLocation();
    const navigate = useNavigate();
    const searchParams = new URLSearchParams(location.search);
    const query = decodeURIComponent(searchParams.get("query")) || "";
    const cleanQuery = query.trim().toLowerCase().replace(/\s+/g, "-");

    useEffect(() => {
        // REJECT EMPTY, NON-WORD, OR TOO SHORT QUERIES
        if (!cleanQuery || cleanQuery.length < 2 || /[^a-z0-9_-]/.test(cleanQuery)) {
            navigate("/not-found", { replace: true });
            return;
        }

        const exactMatch = recipesData.find((recipe) => recipe.slug?.toLowerCase() === cleanQuery);

        if (exactMatch) {
            setResults([exactMatch]);
            return;
        }

        const partialMatches = recipesData.filter((recipe) => recipe.title?.toLowerCase().includes(cleanQuery));

        if (partialMatches.length > 0) {
            setResults(partialMatches);
            return;
        }

        navigate("/not-found", { replace: true });
    }, [ cleanQuery, navigate ]);

    if (!results) return null;

    return (
        <main className="pt-14.5 bg-cream md:py-3 lg:py-7 dark:bg-deep-charcoal-gray">
            <SearchTitle query={ query }/>
            <SearchResult query={ results } />
        </main>
    );
};

export default SearchRecipe;