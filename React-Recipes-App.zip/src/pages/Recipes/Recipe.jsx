import React from "react";
import { useParams } from "react-router-dom";
import recipesData from "/src/assets/data/recipes.json";
import SelectedRecipe from "../../components/sections/SelectedRecipe";
import RecipeDetails from "../../components/sections/RecipeDetails";
import NotFound from "../NotFound";

const Recipe = () => {
    const { dishName } = useParams();
    const selectedRecipe = recipesData.find((recipe) => recipe.slug === dishName);
    return (
        <main className="pt-14.5 bg-cream md:py-3 lg:py-7 dark:bg-deep-charcoal-gray">
            {
                selectedRecipe ? (
                    <>
                        <SelectedRecipe recipe={ selectedRecipe }/>
                        <RecipeDetails recipe={ selectedRecipe }/>
                    </>
                )
                :
                (
                    <NotFound />
                )
            }
        </main>
    )
};

export default Recipe;