import React from "react";
import RecipeBanner from "../../components/sections/RecipeBanner";
import RecipeCards from "../../components/sections/RecipeCards";

const Recipes = () => {

    return (
        <main className="pt-14.5 bg-cream md:py-3 lg:py-7 dark:bg-deep-charcoal-gray">
            <RecipeBanner />
            <RecipeCards paddingTop="pt-16 lg:pt-26" paddingBottom="pb-0"/>
        </main>
    )
};

export default Recipes;