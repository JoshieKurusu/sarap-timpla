import React from 'react';
import AboutBanner from '../components/sections/AboutBanner';
import GreetingSection from '../components/sections/GreetingSection';
import InvitationSection from '../components/sections/InvitationSection';

const About = () => {
    return (
        <main className='pt-16 pb-16 bg-cream md:pt-0 dark:bg-deep-charcoal-gray'>
            <AboutBanner />
            <GreetingSection />
            <InvitationSection />
        </main>
    )
};

export default About;